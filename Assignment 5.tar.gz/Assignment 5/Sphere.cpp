#include <glm/gtc/matrix_transform.hpp>
#include "Sphere.h"
#include <math.h>

using namespace std;
using namespace glm;

Sphere::Sphere(float sphereRadius, vec3 sphereCenter) {
	radius = sphereRadius;
	center = sphereCenter;
	trans = mat4(vec4(0, 0, 0, 0), vec4(0, 0, 0, 0), vec4(0, 0, 0, 0), vec4(center, 0)
	
	//get verticies
	//30 degrees from bottom
	float y = -sqrt(3.f)/2.f;
	float rad = .5f*radius;
	float phi = 0;
	for(int i = 0; i < 12; i++) {
		vertices[0][i] = vec3(center.x+rad*sin(phi), center.y+y*radius, center.z+rad*cos(phi));
		phi += 0.5235987756f;
	}
	
	y = -.5f;
	rad = sqrt(3.f)/2.f*radius;
	phi = 0;
	for(int i = 0; i < 12; i++) {
		vertices[1][i] = vec3(center.x+rad*sin(phi), center.y+y*radius, center.z+rad*cos(phi));
		phi += 0.5235987756f;
	}
	
	y = 0.f;
	rad = 1.f*radius;
	phi = 0;
	for(int i = 0; i < 12; i++) {
		vertices[2][i] = vec3(center.x+rad*sin(phi), center.y+y*radius, center.z+rad*cos(phi));
		phi += 0.5235987756f;
	}
	
	y = .5f;
	rad = sqrt(3.f)/2.f*radius;
	phi = 0;
	for(int i = 0; i < 12; i++) {
		vertices[3][i] = vec3(center.x+rad*sin(phi), center.y+y*radius, center.z+rad*cos(phi));
		phi += 0.5235987756f;
	}
	
	y = sqrt(3.f)/2.f;
	rad = .5f*radius;
	phi = 0;
	for(int i = 0; i < 12; i++) {
		vertices[4][i] = vec3(center.x+rad*sin(phi), center.y+y*radius, center.z+rad*cos(phi));
		phi += 0.5235987756f;
	}
	bottom = vec3(center.x, center.y-radius, center.z);
	top = vec3(center.x, center.y+radius, center.z);
	
	//make triangles
	int i = 0;
	for(int j = 0; j < 12; j++) {
		triangles[i++] = bottom;
		triangles[i++] = vertices[0][j];
		triangles[i++] = vertices[0][(j+1)%12];
	}
	for(int j = 0; j < 4; j++) {
		for(int k = 0; k < 12; k++) {
			triangles[i++] = vertices[j][k];
			triangles[i++] = vertices[j+1][k];
			triangles[i++] = vertices[j][(k+1)%12];
			
			triangles[i++] = vertices[j+1][k];
			triangles[i++] = vertices[j][(k+1)%12];
			triangles[i++] = vertices[j+1][(k+1)%12];
		}
	}
	for(int j = 0; j < 12; j++) {
		triangles[i++] = top;
		triangles[i++] = vertices[4][j];
		triangles[i++] = vertices[4][(j+1)%12];
	}
}

Sphere::Sphere() {
	Sphere(1.f, vec3(0, 0, 0));
}
