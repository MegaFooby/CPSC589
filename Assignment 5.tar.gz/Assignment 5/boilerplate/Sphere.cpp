#include <glm/gtc/matrix_transform.hpp>
#include "Sphere.h"
#include <math.h>
#include <iostream>

using namespace std;
using namespace glm;

Sphere::Sphere(float sphereRadius, vec3 sphereCenter, int tex) {
	texLoc = vec2(0, 802*tex);
	radius = sphereRadius;
	center = sphereCenter;
	angleX = 0;
	angleY = 0;
	angleZ = 0;
	trans = mat4(vec4(radius, 0, 0, 0), vec4(0, radius, 0, 0), vec4(0, 0, radius, 0), vec4(center, 1));
	
	//get verticies
	float y = 0, rad = 0, phi = 0, step = 0;
	for(int j = 0; j < VERTTRI; j++) {
		phi = 0;
		step += 3.1415926/VERTTRI;
		y = -cos(step);
		rad = sin(step);
		for(int i = 0; i < HORTRI; i++) {
			vertices[j][i] = vec3(rad*sin(phi), y, rad*cos(phi));
			phi += 6.28318530718/HORTRI;
		}
	}
	bottom = vec3(0, -1, 0);
	top = vec3(0, 1, 0);
	
	int i = 0;
	for(int j = 0; j < HORTRI; j++) {
		texCoord[i++] = vec2((j*1600)/(HORTRI), 0) + texLoc;
		texCoord[i++] = vec2((j*1600)/(HORTRI), 800/(VERTTRI)) + texLoc;
		texCoord[i++] = vec2(((j+1)*1600)/(HORTRI), 800/(VERTTRI)) + texLoc;
	}
	for(int k = 0; k < VERTTRI-1; k++) {
		for(int j = 0; j < HORTRI; j++) {
			texCoord[i++] = vec2((j*1600)/(HORTRI), ((k+1)*800)/(VERTTRI)) + texLoc;
			texCoord[i++] = vec2((j*1600)/(HORTRI), ((k+2)*800)/(VERTTRI)) + texLoc;
			texCoord[i++] = vec2(((j+1)*1600)/(HORTRI), ((k+1)*800)/(VERTTRI)) + texLoc;
			
			texCoord[i++] = vec2((j*1600)/(HORTRI), ((k+2)*800)/(VERTTRI)) + texLoc;
			texCoord[i++] = vec2(((j+1)*1600)/(HORTRI), ((k+1)*800)/(VERTTRI)) + texLoc;
			texCoord[i++] = vec2(((j+1)*1600)/(HORTRI), ((k+2)*800)/(VERTTRI)) + texLoc;
		}
	}
	for(int j = 0; j < HORTRI; j++) {
		texCoord[i++] = vec2(j/(HORTRI), 800) + texLoc;
		texCoord[i++] = vec2(j/(HORTRI), (VERTTRI*800)/(VERTTRI)) + texLoc;
		texCoord[i++] = vec2((j+1)/(HORTRI), (VERTTRI*800)/(VERTTRI)) + texLoc;
	}
	/*for(int j = 0; j < HORTRI; j++) {
		texCoord[i++] = vec2(j/(HORTRI+1), 0);
		texCoord[i++] = vec2(j/(HORTRI+1), 1/(VERTTRI+1));
		texCoord[i++] = vec2((j+1)/(HORTRI+1), 1/(VERTTRI+1));
	}
	for(int j = 0; j < VERTTRI-1; j++) {
		for(int k = 0; k < HORTRI; k++) {
			texCoord[i++] = vec2((j)/(HORTRI+1), (k+1)/(VERTTRI+1));
			texCoord[i++] = vec2((j+1)/(HORTRI+1), (k+1)/(VERTTRI+1));
			texCoord[i++] = vec2((j)/(HORTRI+1), (k+2)/(VERTTRI+1));
			
			texCoord[i++] = vec2((j+1)/(HORTRI+1), (k+1)/(VERTTRI+1));
			texCoord[i++] = vec2((j)/(HORTRI+1), (k+2)/(VERTTRI+1));
			texCoord[i++] = vec2((j+1)/(HORTRI+1), (k+2)/(VERTTRI+1));
		}
	}
	for(int j = 0; j < HORTRI; j++) {
		texCoord[i++] = vec2(j/(HORTRI+1), 1);
		texCoord[i++] = vec2(j/(HORTRI+1), VERTTRI/(VERTTRI+1));
		texCoord[i++] = vec2((j+1)/(HORTRI+1), VERTTRI/(VERTTRI+1));
	}*/
}

void Sphere::makeTriangles() {
	//make triangles
	int i = 0;
	for(int j = 0; j < HORTRI; j++) {
		triangles[i++] = vec3(trans*vec4(bottom, 1));
		triangles[i++] = vec3(trans*vec4(vertices[0][j], 1));
		triangles[i++] = vec3(trans*vec4(vertices[0][(j+1)%HORTRI], 1));
	}
	for(int j = 0; j < VERTTRI-1; j++) {
		for(int k = 0; k < HORTRI; k++) {
			triangles[i++] = vec3(trans*vec4(vertices[j][k], 1));
			triangles[i++] = vec3(trans*vec4(vertices[j+1][k], 1));
			triangles[i++] = vec3(trans*vec4(vertices[j][(k+1)%HORTRI], 1));
			
			triangles[i++] = vec3(trans*vec4(vertices[j+1][k], 1));
			triangles[i++] = vec3(trans*vec4(vertices[j][(k+1)%HORTRI], 1));
			triangles[i++] = vec3(trans*vec4(vertices[j+1][(k+1)%HORTRI], 1));
		}
	}
	for(int j = 0; j < HORTRI; j++) {
		triangles[i++] = vec3(trans*vec4(top, 1));
		triangles[i++] = vec3(trans*vec4(vertices[VERTTRI-1][j], 1));
		triangles[i++] = vec3(trans*vec4(vertices[VERTTRI-1][(j+1)%HORTRI], 1));
	}
}

Sphere::Sphere() {
	Sphere(1.f, vec3(0, 0, 0), 0);
}

void Sphere::rotateX(float rad) {
	trans = trans*mat4(vec4(1, 0, 0, 0), vec4(0, cos(rad), sin(rad), 0), vec4(0, -sin(rad), cos(rad), 0), vec4(0, 0, 0, 1));
}

void Sphere::rotateY(float rad) {
	trans = trans*mat4(vec4(cos(rad), 0, -sin(rad), 0), vec4(0, 1, 0, 0), vec4(sin(rad), 0, cos(rad), 0), vec4(0, 0, 0, 1));
}

void Sphere::rotateZ(float rad) {
	trans = trans*mat4(vec4(cos(rad), sin(rad), 0, 0), vec4(-sin(rad), cos(rad), 0, 0), vec4(0, 0, 1, 0), vec4(0, 0, 0, 1));
}

void Sphere::move(vec3 movement) {
	trans = trans*mat4(vec4(1, 0, 0, 0), vec4(0, 1, 0, 0), vec4(0, 0, 1, 0), vec4(movement, 1));
}

void Sphere::scale(float factor) {
	trans = trans*mat4(vec4(factor, 0, 0, 0), vec4(0, factor, 0, 0), vec4(0, 0, factor, 0), vec4(0, 0, 0, 1));
}

void Sphere::rotX(float rad) {
	angleX += rad;
}

void Sphere::rotY(float rad) {
	angleY += rad;
}

void Sphere::rotZ(float rad) {
	angleZ += rad;
}

void Sphere::translate(vec3 move) {
	center += move;
}

void Sphere::resize(float size) {
	radius *= size;
}

void Sphere::transform() {
	trans = mat4(1.f);
	this->move(center);
	this->rotateX(angleX);
	this->rotateY(angleY);
	this->rotateZ(angleZ);
	this->scale(radius);
	this->makeTriangles();
}

void Sphere::transform(vec3 newcenter) {
	center = newcenter;
	trans = mat4(1.f);
	this->move(center);
	this->rotateX(angleX);
	this->rotateY(angleY);
	this->rotateZ(angleZ);
	this->scale(radius);
	this->makeTriangles();
}
