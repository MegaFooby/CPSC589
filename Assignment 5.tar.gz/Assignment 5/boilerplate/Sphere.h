#include <glm/glm.hpp>
#include <vector>

#define VERTTRI 31
#define HORTRI 64

class Sphere {
	public:
	glm::vec3 center;
	float radius;
	glm::vec3 vertices[VERTTRI][HORTRI];
	glm::vec3 triangles[HORTRI*VERTTRI*2*3];
	glm::vec2 texCoord[HORTRI*VERTTRI*2*3];
	glm::vec3 top;
	glm::vec3 bottom;
	const unsigned int TRINUM = HORTRI*VERTTRI*2*3;
	glm::vec2 texLoc;
	
	glm::mat4 trans;
	float angleX, angleY, angleZ;
	
	Sphere();
	Sphere(float sphereRadius, glm::vec3 sphereCenter, int tex);
	
	//about own axis
	void rotateX(float rad);
	void rotateY(float rad);
	void rotateZ(float rad);
	void move(glm::vec3 movement);
	void scale(float factor);
	
	void rotX(float rad);
	void rotY(float rad);
	void rotZ(float rad);
	void translate(glm::vec3 move);
	void resize(float size);
	
	void transform();
	void transform(glm::vec3 newcenter);
	void makeTriangles();
};
