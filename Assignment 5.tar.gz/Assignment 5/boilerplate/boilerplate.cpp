// ==========================================================================
// Barebones OpenGL Core Profile Boilerplate
//    using the GLFW windowing system (http://www.glfw.org)
//
// Loosely based on
//  - Chris Wellons' example (https://github.com/skeeto/opengl-demo) and
//  - Camilla Berglund's example (http://www.glfw.org/docs/latest/quick.html)
//
// Author:  Sonny Chan, University of Calgary
// Co-Authors:
//			Jeremy Hart, University of Calgary
//			John Hall, University of Calgary
// Date:    December 2015
// ==========================================================================

#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <iterator>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "texture.h"
#include "Camera.h"
#include "Sphere.h"

using namespace std;
using namespace glm;
// --------------------------------------------------------------------------
// OpenGL utility and support function prototypes

#define PI_F 3.14159265359f

void QueryGLVersion();
bool CheckGLErrors();

string LoadSource(const string &filename);
GLuint CompileShader(GLenum shaderType, const string &source);
GLuint LinkProgram(GLuint vertexShader, GLuint fragmentShader);

bool lbPushed = false;

// --------------------------------------------------------------------------
// Functions to set up OpenGL shader programs for rendering

// load, compile, and link shaders, returning true if successful
GLuint InitializeShaders()
{
	// load shader source from files
	string vertexSource = LoadSource("shaders/vertex.glsl");
	string fragmentSource = LoadSource("shaders/fragment.glsl");
	if (vertexSource.empty() || fragmentSource.empty()) return false;

	// compile shader source into shader objects
	GLuint vertex = CompileShader(GL_VERTEX_SHADER, vertexSource);
	GLuint fragment = CompileShader(GL_FRAGMENT_SHADER, fragmentSource);

	// link shader program
	GLuint program = LinkProgram(vertex, fragment);

	glDeleteShader(vertex);
	glDeleteShader(fragment);

	// check for OpenGL errors and return false if error occurred
	return program;
}

// --------------------------------------------------------------------------
// Functions to set up OpenGL buffers for storing geometry data

struct Geometry
{
	// OpenGL names for array buffer objects, vertex array object
	GLuint  vertexBuffer;
	GLuint  textureBuffer;
	GLuint  colourBuffer;
	GLuint  vertexArray;
	GLsizei elementCount;

	// initialize object names to zero (OpenGL reserved value)
	Geometry() : vertexBuffer(0), colourBuffer(0), vertexArray(0), elementCount(0)
	{}
};

bool InitializeVAO(Geometry *geometry){

	const GLuint VERTEX_INDEX = 0;
	const GLuint TEXTURE_INDEX = 1;

	//Generate Vertex Buffer Objects
	// create an array buffer object for storing our vertices
	glGenBuffers(1, &geometry->vertexBuffer);
	
	glGenBuffers(1, &geometry->textureBuffer);

	//Set up Vertex Array Object
	// create a vertex array object encapsulating all our vertex attributes
	glGenVertexArrays(1, &geometry->vertexArray);
	glBindVertexArray(geometry->vertexArray);

	// associate the position array with the vertex array object
	glBindBuffer(GL_ARRAY_BUFFER, geometry->vertexBuffer);
	glVertexAttribPointer(
		VERTEX_INDEX,		//Attribute index 
		3, 					//# of components
		GL_FLOAT, 			//Type of component
		GL_FALSE, 			//Should be normalized?
		sizeof(vec3),		//Stride - can use 0 if tightly packed
		0);					//Offset to first element
	glEnableVertexAttribArray(VERTEX_INDEX);
	
	glBindBuffer(GL_ARRAY_BUFFER, geometry->textureBuffer);
	glVertexAttribPointer(
		TEXTURE_INDEX,		//Attribute index 
		2, 					//# of components
		GL_FLOAT, 			//Type of component
		GL_FALSE, 			//Should be normalized?
		sizeof(vec2), 		//Stride - can use 0 if tightly packed
		0);					//Offset to first element
	glEnableVertexAttribArray(TEXTURE_INDEX);

	// unbind our buffers, resetting to default state
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	return !CheckGLErrors();
}

// create buffers and fill with geometry data, returning true if successful
bool LoadGeometry(Geometry *geometry, vec3 *vertices, int elementCount, vec2 *texCoord)
{
	geometry->elementCount = elementCount;

	// create an array buffer object for storing our vertices
	glBindBuffer(GL_ARRAY_BUFFER, geometry->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec3)*geometry->elementCount, vertices, GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, geometry->textureBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vec2)*geometry->elementCount, texCoord, GL_STATIC_DRAW);

	//Unbind buffer to reset to default state
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// check for OpenGL errors and return false if error occurred
	return !CheckGLErrors();
}

// deallocate geometry-related objects
void DestroyGeometry(Geometry *geometry)
{
	// unbind and destroy our vertex array object and associated buffers
	glBindVertexArray(0);
	glDeleteVertexArrays(1, &geometry->vertexArray);
	glDeleteBuffers(1, &geometry->vertexBuffer);
	glDeleteBuffers(1, &geometry->textureBuffer);
}

// --------------------------------------------------------------------------
// Rendering function that draws our scene to the frame buffer

void RenderScene(Geometry *geometry, GLuint program, vec3 color, Camera* camera, mat4 perspectiveMatrix, GLenum rendermode)
{

	// bind our shader program and the vertex array object containing our
	// scene geometry, then tell OpenGL to draw our geometry
	glUseProgram(program);

	int vp [4];
	glGetIntegerv(GL_VIEWPORT, vp);
	int width = vp[2];
	int height = vp[3];


	//Bind uniforms
	GLint uniformLocation = glGetUniformLocation(program, "Colour");
	glUniform3f(uniformLocation, color.r, color.g, color.b); 

	mat4 modelViewProjection = perspectiveMatrix*camera->viewMatrix();
	uniformLocation = glGetUniformLocation(program, "modelViewProjection");
	glUniformMatrix4fv(uniformLocation, 1, false, glm::value_ptr(modelViewProjection));

	glBindVertexArray(geometry->vertexArray);
	glDrawArrays(rendermode, 0, geometry->elementCount);

	// reset state to default (no shader or geometry bound)
	glBindVertexArray(0);
	glUseProgram(0);

	// check for an report any OpenGL errors
	CheckGLErrors();
}

// --------------------------------------------------------------------------
// GLFW callback functions

// reports GLFW errors
void ErrorCallback(int error, const char* description)
{
	cout << "GLFW ERROR " << error << ":" << endl;
	cout << description << endl;
}

// handles keyboard input events
void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
}

Camera* cameraPoint;
float* scrollsens;
void ScrollCallback(GLFWwindow* window, double x, double y) {
	cameraPoint->radius -= *scrollsens * y;
	if(cameraPoint->radius < 0.f) {
		cameraPoint->radius = 0.f;
	}
}

// ==========================================================================
// PROGRAM ENTRY POINT

int main(int argc, char *argv[])
{
	// initialize the GLFW windowing system
	if (!glfwInit()) {
		cout << "ERROR: GLFW failed to initialize, TERMINATING" << endl;
		return -1;
	}
	glfwSetErrorCallback(ErrorCallback);

	// attempt to create a window with an OpenGL 4.1 core profile context
	GLFWwindow *window = 0;
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	int width = 1024, height = 1024;
	window = glfwCreateWindow(width, height, "CPSC 453 OpenGL Boilerplate", 0, 0);
	if (!window) {
		cout << "Program failed to create GLFW window, TERMINATING" << endl;
		glfwTerminate();
		return -1;
	}

	// set keyboard callback function and make our context current (active)
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetScrollCallback(window, ScrollCallback);
	glfwMakeContextCurrent(window);

	//Intialize GLAD
	if (!gladLoadGL())
	{
		cout << "GLAD init failed" << endl;
		return -1;
	}

	// query and print out information about our OpenGL environment
	QueryGLVersion();

	// call function to load and compile shader programs
	GLuint program = InitializeShaders();
	if (program == 0) {
		cout << "Program could not initialize shaders, TERMINATING" << endl;
		return -1;
	}


	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	// three vertex positions and assocated colours of a triangle
	/*vec3 vertices[] = {
		vec3( -.6f, -.4f, -0.5f ),
		vec3( .0f,  .6f, -0.5f ),
		vec3( .6f, -.4f,-0.5f )
	};

	vec3 frustumVertices[] = {
		vec3(-1, -1, -1),
		vec3(-1, -1, 1),
		vec3(-1, 1, 1),
		vec3(1, 1, 1),
		vec3(1, 1, -1),
		vec3(-1, 1, -1),
		vec3(-1, -1, -1),
		vec3(1, -1, -1),
		vec3(1, -1, 1),
		vec3(-1, -1, 1),
		vec3(-1, 1, 1),
		vec3(-1, 1, -1),
		vec3(1, 1, -1),
		vec3(1, -1, -1),
		vec3(1, -1, 1),
		vec3(1, 1, 1)
	};*/
	
	Sphere earth = Sphere(.25f, vec3(0, 0, 0), 9);
	earth.rotX(0.4091052f);
	Sphere moon = Sphere(.05f, vec3(0, 0, 0), 7);
	moon.rotX(0.116588f);
	moon.rotY(PI_F/4);
	Sphere sun = Sphere(1.f, vec3(0, 0, 0), 8);
	sun.rotX(0.1265364f);
	vec3 light = sun.center;
	
	const int planetNum = 7;
	Sphere planets[] = {
		Sphere(.11f, vec3(0, 0, 0), 6),//mercury
		Sphere(.22f, vec3(0, 0, 0), 5),//venus
		Sphere(.4f, vec3(0, 0, 0), 4),//mars
		Sphere(.7f, vec3(0, 0, 0), 3),//jupiter
		Sphere(.58f, vec3(0, 0, 0), 2),//saturn
		Sphere(.35f, vec3(0, 0, 0), 1),//uranus
		Sphere(.35f, vec3(0, 0, 0), 0)//neptune
	};
	
	float planetChar[][4] = {//axial tilt, distance from sun, rotational period, orbital period
		{0.f, 2.5f, 58.646225f, 87.9692572f},//merc
		{3.094469f, 5.f, 243.0187f, 224.7007992f},//ven
		{0.4396484f, 8.5f, 1.f, 686.979586f},//mars
		{0.05445427f, 10.f, .41354f, 4332.82013f},//jup
		{0.4665265f, 12.f, .44401f, 10755.6986f},//sat
		{1.707979f, 15.f, .71833f, 30687.153f},//uran
		{0.5162684f, 18.f, .67125f, 60190.0296f}//nept
	};
	
	for(int i = 0; i < planetNum; i++) {
		planets[i].rotX(planetChar[i][0]);
	}
	
	MyTexture tex;
	InitializeTexture(&tex, "Textures.jpg", GL_TEXTURE_RECTANGLE);
	
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_RECTANGLE, tex.textureID);

	mat4 perspectiveMatrix = glm::perspective(PI_F*.4f, float(width)/float(height), .1f, 50.f);//mat4(1.f);	//Fill in with Perspective Matrix

	/*for(int i=0; i<16; i++){
		vec4 newPoint = inverse(perspectiveMatrix)*vec4(frustumVertices[i], 1);
		frustumVertices[i] = vec3(newPoint)/newPoint.w;
	}*/
	
	Geometry earthGeometry;
	Geometry moonGeometry;
	Geometry sunGeometry;
	
	Geometry planetGeometry[planetNum];

	// call function to create and fill buffers with geometry data
	if (!InitializeVAO(&earthGeometry))
		cout << "Program failed to intialize geometry!" << endl;
	if(!LoadGeometry(&earthGeometry, earth.triangles, earth.TRINUM, earth.texCoord))
		cout << "Failed to load geometry" << endl;
	if (!InitializeVAO(&moonGeometry))
		cout << "Program failed to intialize geometry!" << endl;
	if(!LoadGeometry(&moonGeometry, moon.triangles, moon.TRINUM, moon.texCoord))
		cout << "Failed to load geometry" << endl;
	if (!InitializeVAO(&sunGeometry))
		cout << "Program failed to intialize geometry!" << endl;
	if(!LoadGeometry(&sunGeometry, sun.triangles, sun.TRINUM, sun.texCoord))
		cout << "Failed to load geometry" << endl;
	for(int i = 0; i < planetNum; i++) {
		if (!InitializeVAO(&(planetGeometry[i])))
			cout << "Program failed to intialize geometry!" << endl;
		if(!LoadGeometry(&(planetGeometry[i]), planets[i].triangles, planets[i].TRINUM, planets[i].texCoord))
			cout << "Failed to load geometry" << endl;
	}

	glClearColor(0.f, 0.f, 0.f, 1.0f);

	Camera cam = Camera(4.f);
	cameraPoint = &cam;

	vec2 lastCursorPos;

	float cursorSensitivity = PI_F/200.f;	//PI/hundred pixels
	float movementSpeed = 0.01f;
	float scrollSpeed = 0.05f;
	scrollsens = &scrollSpeed;
	double time = 0.0;
	int cameraFollow = 0;
	float timeIncrement = PI_F/100000.f;
	
	GLint cameraGL = glGetUniformLocation(program, "cameraPos");
	GLint lightGL = glGetUniformLocation(program, "light");
	GLint sphereGL = glGetUniformLocation(program, "sphereCenter");

	// run an event-triggered main loop
	while (!glfwWindowShouldClose(window))
	{
		////////////////////////
		//Camera interaction
		////////////////////////
		//Translation
		vec3 movement(0.f);
		
		if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
			movement.z += 1.f;
		if(glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
			movement.z -= 1.f;
		if(glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
			movement.x += 1.f;
		if(glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
			movement.x -= 1.f;
		if(glfwGetKey(window, GLFW_KEY_KP_1) == GLFW_PRESS)
			cameraFollow = 1;
		if(glfwGetKey(window, GLFW_KEY_KP_2) == GLFW_PRESS)
			cameraFollow = 2;
		if(glfwGetKey(window, GLFW_KEY_KP_3) == GLFW_PRESS)
			cameraFollow = 3;
		if(glfwGetKey(window, GLFW_KEY_KP_4) == GLFW_PRESS)
			cameraFollow = 4;
		if(glfwGetKey(window, GLFW_KEY_KP_5) == GLFW_PRESS)
			cameraFollow = 5;
		if(glfwGetKey(window, GLFW_KEY_KP_6) == GLFW_PRESS)
			cameraFollow = 6;
		if(glfwGetKey(window, GLFW_KEY_KP_7) == GLFW_PRESS)
			cameraFollow = 7;
		if(glfwGetKey(window, GLFW_KEY_KP_8) == GLFW_PRESS)
			cameraFollow = 8;
		if(glfwGetKey(window, GLFW_KEY_KP_9) == GLFW_PRESS)
			cameraFollow = 9;
		if(glfwGetKey(window, GLFW_KEY_KP_0) == GLFW_PRESS)
			cameraFollow = 10;
		if(glfwGetKey(window, GLFW_KEY_KP_DECIMAL) == GLFW_PRESS)
			cameraFollow = 0;
		if(glfwGetKey(window, GLFW_KEY_KP_ADD) == GLFW_PRESS)
			timeIncrement += 0.000001;
		if(glfwGetKey(window, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS)
			timeIncrement -= 0.000001;
		
		cam.move(movement*movementSpeed);
	
		//Rotation
		double xpos, ypos;
		
		glfwGetCursorPos(window, &xpos, &ypos);
		vec2 cursorPos(xpos, ypos);
		vec2 cursorChange = cursorPos - lastCursorPos;
		lastCursorPos = cursorPos;
		
		if(glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS) {
			cam.rotateHorizontal(-cursorChange.x*cursorSensitivity);
			cam.rotateVertical(-cursorChange.y*cursorSensitivity);
		}

		///////////
		//Drawing
		//////////

		// clear screen to a dark grey colour
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		time += timeIncrement;
		
		earth.rotY(-(float)time/1.f);
		float earthRot = (float)time*(200*PI_F)/365.25f;
		vec3 earthPos = 7.f*vec3(-sin(earthRot), 0.f, cos(earthRot));
		earth.transform(earthPos);
		
		moon.rotY(-(float)time/27.32158f);
		float moonRot = (float)time*(200*PI_F)/27.32158f;
		vec3 moonPos = .5f*vec3(sin(moonRot), 0.f, cos(moonRot));
		moon.transform(earthPos+moonPos);
		
		sun.rotY(-(float)time/25.38f);
		sun.transform();
		
		for(int i = 0; i < planetNum; i++) {
			planets[i].rotY(-(float)time/planetChar[i][2]);
			float rotation = (float)time*(200*PI_F)/planetChar[i][3];
			vec3 planetPos = planetChar[i][1]*vec3(-sin(rotation), 0.f, cos(rotation));
			planets[i].transform(planetPos);
		}
		
		if(cameraFollow == 1)
			cam.pos = sun.center;
		else if(cameraFollow == 2)
			cam.pos = earth.center;
		else if(cameraFollow == 3)
			cam.pos = moon.center;
		else if(cameraFollow != 0)
			cam.pos = planets[cameraFollow-4].center;
		
		glUseProgram(program);
		glUniform3fv(cameraGL, 1, &(cam.pos.x));
		glUniform3fv(lightGL, 1, &(light.x));
		
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_RECTANGLE, tex.textureID);
		
		LoadGeometry(&earthGeometry, earth.triangles, earth.TRINUM, earth.texCoord);
		LoadGeometry(&moonGeometry, moon.triangles, moon.TRINUM, moon.texCoord);
		LoadGeometry(&sunGeometry, sun.triangles, sun.TRINUM, sun.texCoord);
		
		for(int i = 0; i < planetNum; i++) {
			LoadGeometry(&(planetGeometry[i]), planets[i].triangles, planets[i].TRINUM, planets[i].texCoord);
		}

		// call function to draw our scene
		glUseProgram(program);
		glUniform3fv(sphereGL, 1, &(earth.center.x));
		RenderScene(&earthGeometry, program, vec3(0, 0, 1), &cam, perspectiveMatrix, GL_TRIANGLES);
		glUseProgram(program);
		glUniform3fv(sphereGL, 1, &(moon.center.x));
		RenderScene(&moonGeometry, program, vec3(.5, .5, .5), &cam, perspectiveMatrix, GL_TRIANGLES);
		glUseProgram(program);
		glUniform3fv(sphereGL, 1, &(sun.center.x));
		RenderScene(&sunGeometry, program, vec3(1, 1, 0), &cam, perspectiveMatrix, GL_TRIANGLES);
		
		for(int i = 0; i < planetNum; i++) {
			glUseProgram(program);
			glUniform3fv(sphereGL, 1, &(planets[i].center.x));
			RenderScene(&(planetGeometry[i]), program, vec3(0, 1, 0), &cam, perspectiveMatrix, GL_TRIANGLES);
		}

		glfwSwapBuffers(window);

		glfwPollEvents();
	}

	// clean up allocated resources before exit
	DestroyGeometry(&earthGeometry);
	DestroyGeometry(&moonGeometry);
	DestroyGeometry(&sunGeometry);
	glUseProgram(0);
	glDeleteProgram(program);
	glfwDestroyWindow(window);
	glfwTerminate();

	cout << "Goodbye!" << endl;
	return 0;
}

// ==========================================================================
// SUPPORT FUNCTION DEFINITIONS

// --------------------------------------------------------------------------
// OpenGL utility functions

void QueryGLVersion()
{
	// query opengl version and renderer information
	string version = reinterpret_cast<const char *>(glGetString(GL_VERSION));
	string glslver = reinterpret_cast<const char *>(glGetString(GL_SHADING_LANGUAGE_VERSION));
	string renderer = reinterpret_cast<const char *>(glGetString(GL_RENDERER));

	cout << "OpenGL [ " << version << " ] "
		<< "with GLSL [ " << glslver << " ] "
		<< "on renderer [ " << renderer << " ]" << endl;
}

bool CheckGLErrors()
{
	bool error = false;
	for (GLenum flag = glGetError(); flag != GL_NO_ERROR; flag = glGetError())
	{
		cout << "OpenGL ERROR:  ";
		switch (flag) {
		case GL_INVALID_ENUM:
			cout << "GL_INVALID_ENUM" << endl; break;
		case GL_INVALID_VALUE:
			cout << "GL_INVALID_VALUE" << endl; break;
		case GL_INVALID_OPERATION:
			cout << "GL_INVALID_OPERATION" << endl; break;
		case GL_INVALID_FRAMEBUFFER_OPERATION:
			cout << "GL_INVALID_FRAMEBUFFER_OPERATION" << endl; break;
		case GL_OUT_OF_MEMORY:
			cout << "GL_OUT_OF_MEMORY" << endl; break;
		default:
			cout << "[unknown error code]" << endl;
		}
		error = true;
	}
	return error;
}

// --------------------------------------------------------------------------
// OpenGL shader support functions

// reads a text file with the given name into a string
string LoadSource(const string &filename)
{
	string source;

	ifstream input(filename.c_str());
	if (input) {
		copy(istreambuf_iterator<char>(input),
			istreambuf_iterator<char>(),
			back_inserter(source));
		input.close();
	}
	else {
		cout << "ERROR: Could not load shader source from file "
			<< filename << endl;
	}

	return source;
}

// creates and returns a shader object compiled from the given source
GLuint CompileShader(GLenum shaderType, const string &source)
{
	// allocate shader object name
	GLuint shaderObject = glCreateShader(shaderType);

	// try compiling the source as a shader of the given type
	const GLchar *source_ptr = source.c_str();
	glShaderSource(shaderObject, 1, &source_ptr, 0);
	glCompileShader(shaderObject);

	// retrieve compile status
	GLint status;
	glGetShaderiv(shaderObject, GL_COMPILE_STATUS, &status);
	if (status == GL_FALSE)
	{
		GLint length;
		glGetShaderiv(shaderObject, GL_INFO_LOG_LENGTH, &length);
		string info(length, ' ');
		glGetShaderInfoLog(shaderObject, info.length(), &length, &info[0]);
		cout << "ERROR compiling shader:" << endl << endl;
		cout << source << endl;
		cout << info << endl;
	}

	return shaderObject;
}

// creates and returns a program object linked from vertex and fragment shaders
GLuint LinkProgram(GLuint vertexShader, GLuint fragmentShader)
{
	// allocate program object name
	GLuint programObject = glCreateProgram();

	// attach provided shader objects to this program
	if (vertexShader)   glAttachShader(programObject, vertexShader);
	if (fragmentShader) glAttachShader(programObject, fragmentShader);

	// try linking the program with given attachments
	glLinkProgram(programObject);

	// retrieve link status
	GLint status;
	glGetProgramiv(programObject, GL_LINK_STATUS, &status);
	if (status == GL_FALSE)
	{
		GLint length;
		glGetProgramiv(programObject, GL_INFO_LOG_LENGTH, &length);
		string info(length, ' ');
		glGetProgramInfoLog(programObject, info.length(), &length, &info[0]);
		cout << "ERROR linking shader program:" << endl;
		cout << info << endl;
	}

	return programObject;
}
